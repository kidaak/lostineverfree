<?php
class WPBakeryShortCode_VC_Column_text extends WPBakeryShortCode {
}