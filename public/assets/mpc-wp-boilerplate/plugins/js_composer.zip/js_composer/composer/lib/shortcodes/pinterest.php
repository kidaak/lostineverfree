<?php
class WPBakeryShortCode_VC_Pinterest extends WPBakeryShortCode {
}